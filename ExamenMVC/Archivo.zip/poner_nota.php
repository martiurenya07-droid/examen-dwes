<?php
//empezamos sesión
session_start();

//denegamos acceso a página si no hay usuario
if (!isset($_SESSION["username"])) {
    //redirigimos a login
    header("Location:login.php");
    exit();
}

//guardamos usuario
$username = $_SESSION["username"];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poner nota</title>
</head>
<body>
    <h1>Poner nota</h1>

</body>
</html>